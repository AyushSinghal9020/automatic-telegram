import os 

print(os.listdir('Assets/uploads'))